export default function Footer() {
  return (
    <footer className="bg-black text-yellow-400 py-6 text-center">
      <p className="text-sm">&copy; 2025 Forex Fusion. All rights reserved.</p>
    </footer>
  );
}
